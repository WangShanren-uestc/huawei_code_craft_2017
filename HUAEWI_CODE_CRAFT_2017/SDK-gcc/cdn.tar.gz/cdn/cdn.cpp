#include "deploy.h"
#include "lib_io.h"
#include "lib_time.h"
#include "stdio.h"
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
        print_time("Begin");
        char *topo[MAX_EDGE_NUM];
        int line_num;

        char *topo_file = argv[1];

        line_num = read_file(topo, MAX_EDGE_NUM, topo_file);

        printf("line num is :%d \n", line_num);
        if (line_num == 0)
        {
                printf("Please input valid topo file.\n");
                return -1;
        }

        char *result_file = argv[2];

        deploy_server(topo, line_num, result_file);

        release_buff(topo, line_num);
/*************************/
       // Py_Initialize();
       //  // 检查初始化是否成功
       //  if ( !Py_IsInitialized() )
       //  {
       //          return -1;
       //  }
       //  PyRun_SimpleString("import sys");
       //  PyRun_SimpleString("sys.path.append('/home/w/huwei_2017/SDK-gcc/cdn')");
       //
       //  PyObject *pName,*pModule,*pDict,*pFunc,*pArgs;
       //  pName = PyString_FromString("show_net");
       //  pModule = PyImport_Import(pName);
       //  if ( !pModule )
       //  {
       //          printf("can't find show_net.py");
       //          getchar();
       //          return -1;
       //  }
       //  pDict = PyModule_GetDict(pModule);
       //  if ( !pDict )
       //  {
       //          return -1;
       //  }
       //  printf("----------------------\n");
       //  pFunc = PyDict_GetItemString(pDict, "show_net");
       //  if ( !pFunc || !PyCallable_Check(pFunc) ) {
       //          printf("can't find function [show_net]");
       //          getchar();
       //          return -1;
       //  }
       //  pArgs = PyTuple_New(2);
       //  string name;
       //  string show_weight;
       //  cout<<"Assign case to plot,range:(0~4)? ";
       //  cin>>name;
       //  cout<<"Show edge weight:y/n? ";
       //  cin>>show_weight;
       //
       //
       //  PyTuple_SetItem(pArgs, 0, Py_BuildValue("s",name.c_str()));
       //  PyTuple_SetItem(pArgs, 1, Py_BuildValue("s",show_weight.c_str()));
       //  PyObject_CallObject(pFunc, pArgs);
       //
       //  Py_DECREF(pName);
       //  Py_DECREF(pArgs);
       //  Py_DECREF(pModule);
       //  // 关闭Python
       //  Py_Finalize();
/*************************/


        print_time("End");

        return 0;
}
