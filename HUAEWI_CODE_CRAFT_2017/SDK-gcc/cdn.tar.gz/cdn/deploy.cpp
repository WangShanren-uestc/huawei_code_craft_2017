#include "deploy.h"
#include <algorithm>
#include <math.h>


#define T 500
#define eps 1
#define delta 0.98
#define INF 2147483647
#define iter 15
using namespace std;
int MaxInt = ~0U>>1;
const int Max_Edge = 20000;
bool v[Max_Edge];
etype *e[Max_Edge];
etype *e_buf[Max_Edge];
etype *Pe = new etype[Max_Edge];
etype *Pe_buf = new etype[Max_Edge];
int Peppcount = 0;
int super_sink = 0, super_source = 1, edge_num = 0, pi1 = 0, cost = 0;

int Cons_band = 0;
///my way
vector< vector<int> > wayList;
vector<int> cWay;
vector<int> wayBand;

// int mm = 0;
// etype *Pes;
void newPathway(int endp,int band){
        ////////////cout<<"a new way start"<<endl;
        cWay.clear();
        cWay.push_back(endp);
        ////////////cout<<"now ways num:"<<wayList.size()<<endl;
        wayBand.push_back(band);
////cout<<"wayBand:"<<wayBand.size()<<endl;
}
void extendPathway(int p,Graph &graph,Consume &cons){
        cWay.push_back(p);
        return;
}
void endPathway(void){
        wayList.push_back(cWay);
}
void printPathway(void){
        //cout<<"Start printing Pathways"<<endl;
        for(int i = 1; i < wayList.size(); i++) {
                cout<<"way ["<<i<<"]:";
                for(int j = 0; j < wayList.at(i).size(); j++) {
                        cout<<wayList.at(i).at(j)<<"<-";
                }
                cout<<" band:"<<wayBand.at(i-1);
                cout<<endl;
        }
}

void printPathway(vector< vector<int> > waylist){
        //cout<<"Start printing waylist"<<endl;
        for(int i = 1; i < waylist.size(); i++) {
                cout<<"way ["<<i<<"]:";
                for(int j = 0; j < waylist.at(i).size(); j++) {
                        cout<<waylist.at(i).at(j)<<"<-";
                }
                cout<<endl;
        }
}


//输入待匹配的char, 字符转换成int返回

inline vector<int> read_line(char * Line)
{
        string c;
        vector<int> output;
        unsigned short count = 0, last_count = 0;
        while(Line[count] != 0x0a && Line[count] != 0x0d)
        {
                if(Line[count] == ' ')
                {
                        for(int i=last_count; i<count; i++)
                                c = c + Line[i];
                        output.push_back(atoi(c.c_str()));
                        c.clear();
                        last_count = count + 1;
                }
                count++;
        }
        for(int i=last_count; i<count; i++)
                c = c + Line[i];
        output.push_back(atoi(c.c_str()));
        return output;
}

inline void cal_mat(char * topo[MAX_EDGE_NUM], Graph &graph, Consume &cons,
                    const int line_num, int &serve_price)
{
        vector<int> buf = read_line(topo[0]);
        graph.node_num = buf[0];
        graph.edge_num = buf[1];
        cons.node_num = buf[2];

        buf = read_line(topo[2]);
        serve_price = buf[0];

        int count = 4;
        buf = read_line(topo[count]);

        vector<pair<int,int> > row(graph.node_num,make_pair(0,0));
        vector<pair<int,int> > empty(graph.node_num,make_pair(0,0));
        for(int i = 0; i<graph.node_num; i++)
        {
                graph.nodes.push_back(i+2);
        }
        //get
        while(buf.size()>1)
        {
                graph.edges.push_back(make_pair(buf[0]+2, buf[1]+2));
                //all price * 2 to avoid using float
                graph.supply.push_back(make_pair(buf[2], 2 * buf[3]));

                count++;
                buf = read_line(topo[count]);
        }
        count++;
        while(count<line_num)
        {
                buf = read_line(topo[count]);
                cons.nodes.push_back(buf[1]+2);
                cons.demand.push_back(buf[2]);
                Cons_band+=buf[2];
                count++;
        }
}

inline void print_graph(const Graph &g, const Consume &c)
{
        //////////cout<<"Node Num:"<<g.node_num<<"  edge Num:"<<g.edge_num<<endl;
        //////////cout<<"node list: ";
        for(auto i:g.nodes)
        {
                //////////cout<<i<<" ";
        }
        //////////cout<<endl;

        int count = 0;
        for(auto i:g.edges)
        {
                //////////cout<<"edges(a,b):"<<count<<"   ";
                //////////cout<<i.first<<" "<<i.second<<endl;
                count++;
        }
        count = 0;
        for(auto i:g.supply)
        {
                //////////cout<<"supply(band,price):"<<count<<"   ";
                //////////cout<<i.first<<" "<<i.second<<endl;
                count++;
        }
        count = 0;
        for(int i = 0; i<c.node_num; i++)
        {
                //////////cout<<"consume(node,band):"<<count<<"   ";
                //////////cout<<c.nodes[i]<<" "<<c.demand[i]<<endl;
                count++;
        }
}

inline void add_single_edge(const int &s, const int &t, const int &u, const int &c)//u:capacity, c:cost,price
{
        e[s] = new(Pe++)etype(t, c,u,e[s]);
        e[t] = new(Pe++)etype(s,-c,0,e[t]);
        e[s]->pair = e[t];
        e[t]->pair = e[s];
        Peppcount +=2;
        // //////////cout<<"edge: ("<<s<<","<<t<<")"<<e[s]->c<<" "<<e[s]->u<<endl;
}
void modify_single_edge(const int &s, const int &t, const int &capacity, const int &price) //u:capacity, c:cost,price
{
        for(etype *i = e[s]; i; i = i->next)
        {
                if(i->t == t)
                {
                        i->c = price;
                        i->u = capacity;
                        // //////////cout<<"after edge: ("<<s<<","<<i->t<<")"<<i->c<<" "<<i->u<<endl;
                        break;
                }
        }
}
int vec_find(std::vector<std::pair<int,int> > vec,const pair<int,int>&pa)
{
        for(std::vector<pair<int,int> >::iterator it=vec.begin(); it!=vec.end(); it++)
        {
                if(it->first == pa.first && it->second == pa.second)
                        return distance(vec.begin(),it);
        }

        return 1;
}
int vir_find(vector<pair<int,pair<int,int> > > &vi,const pair<int,int>&pa)
{
        for(vector<pair<int,pair<int,int> > >::iterator it=vi.begin(); it!=vi.end(); it++)
        {
                if(it->second.first == pa.first && it->first == pa.second)
                        return distance(vi.begin(),it);
                if(it->first == pa.first && it->second.second == pa.second)
                        return distance(vi.begin(),it);
        }
        return 1;
}
void modify_node_edge(const int &s,const Graph &graph, vector<pair<int,pair<int,int> > > &vi, const Consume &cons)
{
        for(etype *i=e[s]; i; i=i->next)
        {
                if(s>graph.node_num+1 || i->t>graph.node_num+1)// maybe consume node
                {
                        if(s>graph.node_num+graph.edge_num+1 || i->t>graph.node_num+graph.edge_num+1)
                        {
                                if(i->t > s)
                                {
                                        int index = max(s,i->t) - graph.node_num - graph.edge_num - 2;
                                        i->c =  0;
                                        i->u = cons.demand[index];
                                        modify_single_edge(i->t, s, 0, 0);
                                }
                                else continue;
                        }
                        else
                        {
                                int index = vir_find(vi,make_pair(s,i->t));
                                if(index == 1)
                                        continue;
                                //     //////////cout<<"virtual index:"<<index<<" s and t:"<<s<<" "<<i->t<<endl;
                                //     //////////cout<<"virtual index:"<<index<<" s and t:"<<s<<" "<<graph.supply[index].second<<endl;
                                i->c =  graph.supply[index].second/2;
                                i->u = graph.supply[index].first;
                                modify_single_edge(i->t, s, 0, -graph.supply[index].second/2);
                        }
                }
                else
                {
                        int index = vec_find(graph.edges,make_pair(s,i->t));
                        if(index == 1)
                                continue;
                        //    //////////cout<<"real index:"<<index<<" s and t:"<<s<<" "<<i->t<<endl;
                        i->c =  graph.supply[index].second;
                        i->u = graph.supply[index].first;
                        modify_single_edge(i->t, s, 0, -graph.supply[index].second);
                }
        }
}

void reset(const Graph &graph,vector<pair<int,pair<int,int> > > &vi, const Consume &cons)
{
        memcpy(e,e_buf,Max_Edge * sizeof(size_t));
        memcpy(Pe,Pe_buf,Max_Edge * sizeof(Pe));
        // int count = super_source+1;
        // while(count<super_sink)
        // {
        //         modify_node_edge(count, graph, vi, cons);
        //         count++;
        // }
        // for(etype *i = e[super_source]; i; i = i->next)
        // {
        //         i->c = 0;
        //         i->u = 0;
        //         modify_single_edge(i->t, super_source, 0, 0);
        // }
        // for(etype *i = e[super_sink]; i; i = i->next)
        // {
        //         i->c = 0;
        //         i->u = 0;
        //         modify_single_edge(i->t, super_sink, MaxInt, 0);
        // }

}

void modify_source_edges(const vector<int> &service_loc)
{
        // //////////cout<<"service_loc.size(): "<<service_loc.size()<<endl;
        for(unsigned int i=2; i<service_loc.size(); i++)//2~51, size = 52
        {
                if(service_loc[i]==0)
                {
                        modify_single_edge(super_source, i, 0, 0);
                }
                else
                {
                        modify_single_edge(super_source, i, MaxInt, 0);
                }
        }
}
//add edge:super_source to service location
inline void add_source_edges(const Graph &graph)
{
        //////////cout<<"super_source "<<super_source<<endl;
        for(int i = 0; i<graph.node_num; i++)//list from 1:~
        {
                add_single_edge(super_source,graph.nodes[i],0,0);
        }
}
//add edge:network edges and using one virtual node to add two virtual sides
inline void add_net_edges(const Graph &graph, vector<pair<int,pair<int,int> > > &virtual_node)
{
        int num = graph.node_num + 2;
        // //////////cout<<"ssd"<<num<<"  "<<graph.edge_num<<" "<<graph.supply.size()<<endl;
        //////////cout<<"virtual node: ";
        for(int i = 0; i<graph.edge_num; i++)
        {
                //////////cout<<num<<",";
                add_single_edge(graph.edges[i].first, graph.edges[i].second,
                                graph.supply[i].first, graph.supply[i].second);

                add_single_edge(graph.edges[i].second, num,
                                graph.supply[i].first, graph.supply[i].second/2);

                add_single_edge(num, graph.edges[i].first,
                                graph.supply[i].first, graph.supply[i].second/2);

                virtual_node.push_back(make_pair(num,make_pair(graph.edges[i].second,graph.edges[i].first)));
                num++;
        }
        //////////cout<<endl;
}

inline void add_sink_edges(Graph &g, const Consume &cons)
{
        //add edge: add edges from consume nodes to super sink
        //////////cout<<"super_sink "<<super_sink<<endl;
        int num = g.node_num + g.edge_num + 2;
        for(int i = 0; i<cons.node_num; i++)
        {
                add_single_edge(cons.nodes[i], num, cons.demand[i], 0);
                add_single_edge(num, super_sink, MaxInt, 0);
                num++;
        }
}

inline void print_edges()
{
        int line_count = 0;
        int count = 0;
        // spdlog::get("console")->info("fuck");
        while(count<=super_sink)
        {
                etype * row = e[count];
                while(row)
                {
                        if(row->c<-100)
                        {
                                //cout<<" danjia weifu:"<<row->c<<endl;
                                // exit(0);
                        }
                        if(row->u < -200)
                        {
                                //cout<<" daikuan weifu:"<<row->u<<endl;
                                // exit(0);
                        }
                        //cout<<"e:"<<line_count<<" ("<<count<<","<<row->t<<") band: "<<row->u<<" price:"<<row->c<<endl;
                        row = row->next;
                        line_count = line_count+1;
                }
                count++;
        }
}

// void myprint(void){
//         return;
//         //////////cout<<"start printing Pe"<<endl;
//
//         for(int i = 0; i < mm*2; i++) {
//                 //////////cout<<i<<' ';
//                 etype *ee=&Pes[i];
//                 //////////cout<<"to="<<ee->t<<' ';
//                 //////////cout<<"price="<<ee->c<<' ';
//                 //////////cout<<"band="<<ee->u<<' '<<endl;
//                 if(i%2) //////////cout<<endl;
//         }
//         //////////cout<<"v[]:";
//         for(int i= 0; i < mm*2; i++) {
//                 //////////cout<<v[i]<<' ';
//         }
//         //////////cout<<endl;
// }

inline int aug(int no, int m,Graph &graph,Consume &cons)
{
        if(no == super_sink)
        {

                endPathway();
                newPathway(no,m);
                cost += pi1 * m;
                // //cout<<"cost:"<<cost<<"  pi1: "<<pi1<<"  m: "<<m<<endl;
                return m;
        }
        v[no] = true;
        int l = m;
        for(etype *i = e[no]; i; i = i->next)
        {
                if(i->u && !i->c && !v[i->t])
                {
                        int d = aug(i->t,l<i->u ? l : i->u,graph,cons);
                        i->u -= d;
                        i->pair->u += d;
                        l -= d;
                        ///my way
                        if(d) extendPathway(no,graph,cons);
                               // ////cout<<"cur no:"<<no<<" d:"<<d<<" m:"<<m<<" l:"<<l<<endl;}
                        if(!l) return m;
                }
        }
        return m-l;
}

inline bool modlabel()
{
        int d = MaxInt;
        for(int i = 1; i <= super_sink; ++i)
        {
                if(v[i])
                {
                        for(etype *j = e[i]; j; j = j->next)
                        {
                                if(j->u && !v[j->t] && j->c<d)
                                {
                                        d = j->c;
                                }
                        }
                }
        }
        if(d == MaxInt)
        {
                return false;
        }
        for(int i = 1; i <= super_sink; ++i)
        {
                if(v[i])
                {
                        for(etype *j = e[i]; j; j = j->next)
                        {
                                j->c -= d;
                                j->pair->c += d;
                        }
                }
        }

        pi1 += d;
        //  //////////cout<<"pi1 and d"<<pi1<<" "<<d<<endl;
        return true;
}

inline void zkw(const int &service_num,const vector<int> &service_loc, const int &price,Graph &graph,Consume &cons)
{
        // super_sink = 147;
        // edge_num = 3 * graph.edge_num + cons.node_num + service_num;//

        wayList.clear();
        cWay.clear();
        wayBand.clear();
        do do memset(v,0,sizeof(v));
                while(aug(1,MaxInt,graph,cons));
        while(modlabel());
        endPathway();
        //   printPathway();
          // cout<<"edge cost: "<<cost/2<<"  ";
          //  if(!cost) cout<<"sfsdfsdgfsdgfdf"<<service_num<<" "<<price<<endl;
          //  else cout<<"nomal"<<service_num<<" "<<price<<endl;
        if(cost<0)
        {
                //cout<<"err cost"<<cost<<endl;
                printPathway();
                //   cost = INF;
        }
        else{
                cost = cost/2 + service_num * price;
        }
   //    cout<<"service_num,price:"<<service_num<<","<<price<<"  cost:"<<cost<<endl;
}
int nodeExport(const int &s)
{
        int totale=0;
        for(etype *i=e[s]; i; i=i->next)
        {
                totale+=i->u;
        }
        return totale;
}

void calcuZKW(vector<int>&serviceVec,int serviceNum,Graph &graph,Consume & cons,const int &s_price)
{
        // reset();
        // int service_num=0;
        // vector<int> service_loc(graph.node_num + 2, 0);
        // service_loc[4] = 1;
        // service_num++;
        // service_loc[7] = 1;
        // service_num++;
        // service_loc[14] = 1;
        // service_num++;
        // service_loc[19] = 1;
        // service_num++;
        // service_loc[22] = 1;
        // service_num++;
        // service_loc[24] = 1;
        // service_num++;
        // service_loc[32] = 1;
        // service_num++;
        // service_loc[33] = 1;
        // service_num++;
        // service_loc[37] = 1;
        // service_num++;
        // service_loc[38] = 1;
        // service_num++;
        // service_loc[39] = 1;
        // service_num++;
        // service_loc[43] = 1;
        // service_num++;
        // service_loc[44] = 1;
        // service_num++;
        // service_loc[45] = 1;
        // service_num++;
        // service_loc[51] = 1;
        // service_num++;
        // service_loc[60] = 1;
        // service_num++;
        // service_loc[62] = 1;
        // service_num++;
        // service_loc[74] = 1;
        // service_num++;
        // service_loc[75] = 1;
        // service_num++;
        // service_loc[78] = 1;
        // service_num++;
        // service_loc[79] = 1;
        // service_num++;
        // service_loc[80] = 1;
        // service_num++;
        // service_loc[83] = 1;
        // service_num++;
        // service_loc[84] = 1;
        // service_num++;
        // service_loc[86] = 1;
        // service_num++;
        // service_loc[87] = 1;
        // service_num++;
        //
        // service_loc[90] = 1;
        // service_num++;
        // service_loc[94] = 1;
        // service_num++;
        // service_loc[96] = 1;
        // service_num++;
        // service_loc[98] = 1;
        // service_num++;
        // service_loc[99] = 1;
        // service_num++;
        // service_loc[101] = 1;
        // service_num++;
        // service_loc[102] = 1;
        // service_num++;
        // service_loc[103] = 1;
        // service_num++;
        // service_loc[106] = 1;
        // service_num++;
        // service_loc[111] = 1;
        // service_num++;
        // service_loc[123] = 1;
        // service_num++;
        // service_loc[124] = 1;
        // service_num++;
        // service_loc[127] = 1;
        // service_num++;
        // service_loc[130] = 1;
        // service_num++;
        // service_loc[131] = 1;
        // service_num++;
        // service_loc[132] = 1;
        // service_num++;
        // service_loc[133] = 1;
        // service_num++;
        //
        // service_loc[140] = 1;
        // service_num++;
        // service_loc[151] = 1;
        // service_num++;
        // service_loc[157] = 1;
        // service_num++;
        // service_loc[161] = 1;
        // service_num++;
        // service_loc[164] = 1;
        // service_num++;
        // service_loc[170] = 1;
        // service_num++;
        // service_loc[176] = 1;
        // service_num++;
        // service_loc[185] = 1;
        // service_num++;
        // service_loc[187] = 1;
        // service_num++;
        // service_loc[188] = 1;
        // service_num++;
        // service_loc[196] = 1;
        // service_num++;
        // service_loc[205] = 1;
        // service_num++;
        // service_loc[212] = 1;
        // service_num++;
        // service_loc[215] = 1;
        // service_num++;
        // service_loc[218] = 1;
        // service_num++;
        // service_loc[229] = 1;
        // service_num++;
        // service_loc[230] = 1;
        // service_num++;
        //
        // service_loc[233] = 1;
        // service_num++;
        // service_loc[247] = 1;
        // service_num++;
        // service_loc[248] = 1;
        // service_num++;
        // service_loc[250] = 1;
        // service_num++;
        // service_loc[252] = 1;
        // service_num++;
        // service_loc[254] = 1;
        // service_num++;
        // service_loc[255] = 1;
        // service_num++;
        // service_loc[256] = 1;
        // service_num++;
        // service_loc[262] = 1;
        // service_num++;
        // service_loc[264] = 1;
        // service_num++;
        // service_loc[269] = 1;
        // service_num++;
        // service_loc[270] = 1;
        // service_num++;
        // service_loc[271] = 1;
        // service_num++;
        // service_loc[275] = 1;
        // service_num++;
        // service_loc[280] = 1;
        // service_num++;
        // service_loc[287] = 1;
        // service_num++;
        // service_loc[290] = 1;
        // service_num++;
        // service_loc[298] = 1;
        // service_num++;
        // service_loc[299] = 1;
        // service_num++;
        modify_source_edges(serviceVec);
        // print_edges();
        zkw(serviceNum, serviceVec, s_price,graph,cons);
        // printPathway();
        //cout<<"cost: "<<cost<<endl;
        // exit(0);

}
struct chromosome
{
        /* chromosome(){
             serviceRow.clear();
           serviceSerial.clear();
           chromWayList.clear();
           };*/
        vector<int> serviceRow;
        int serviceNum;
        vector<int> serviceSerial;
        int cost;
        double fitness;
        vector< vector<int> > chromWayList;
        bool flag;
};

vector<chromosome> PopulationVec;        //(0);
chromosome resultChrom;
chromosome curentBest_solution;
chromosome best_solution;
bool check(const Consume &cons, const vector<int> &ser,chromosome &sample)
{
        int bandWay=0;
        if(wayBand.size()<cons.node_num)
        {
                //    //cout<<"wayBand size:"<<wayBand.size()<<endl;
                return false;
        }
        if(cost<0 || cost == INF)
        {
                //cout<<"check: "<<sample.cost<<endl;
                //cout<<"err info: "<<endl;
                //cout<<"err cost: "<<sample.cost<<endl;
                //cout<<"err seviceNum: "<<sample.serviceNum<<endl;
                //cout<<"err seviceLoc: ";

                for(auto it:sample.serviceSerial)
                        //cout<<it<<" ";
                //cout<<endl;
            //    exit(0);
                return false;
        }

        for(auto it:wayBand)
                bandWay+=it;
        if(bandWay<Cons_band)
        {
                //    //cout<<"bandWay:"<<bandWay<<endl;
                return false;
        }

        for(int i = 1; i<wayList.size(); i++)
        {
                //      //cout<<"waylist size:"<<wayList.size()<<endl;
                if(wayList.at(i).back()!=1 && find(ser.begin(),ser.end(),wayList.at(i).back())==ser.end())
                        return false;
        }
        return true;
}
chromosome creatOneChro(const Graph &g,const Consume &cons)
{
        chromosome sample;
        int k,exportTotal;
        vector<int> vec(g.node_num+2,0);
        sample.serviceRow = vec;
        sample.serviceNum = 0;
        sample.serviceSerial.clear();
        sample.cost = INF;
        sample.fitness = 0;

        /*   sample.serviceRow.at(11)=1;
           sample.serviceRow.at(12)=1;
           sample.serviceRow.at(14)=1;
           sample.serviceRow.at(17)=1;
           sample.serviceRow.at(18)=1;
           sample.serviceRow.at(42)=1;
           sample.serviceRow.at(43)=1;
           sample.serviceRow.at(44)=1;*/
        for(int i=0; i<cons.node_num; i++)
        {
                sample.serviceRow.at(cons.nodes[i]) = 1;
                sample.serviceSerial.push_back(cons.nodes[i]);
                sample.serviceNum++;
        }
        int data=0;
        for(auto it:sample.serviceRow)
        {
                if(it==1)
                        data++;
        }
        // cout<<"data "<<data<<endl;
        return sample;

        do
        {
                sample.serviceRow = vec;
                sample.serviceNum = 0;
                sample.serviceSerial.clear();

                //   while(sample.serviceNum<cons.node_num/2)
                sample.serviceNum = cons.node_num;//random(cons.node_num);
                for(int i=0; i<sample.serviceNum; i++)
                {
                        do k = random(sample.serviceRow.size());
                        while(k<2||sample.serviceRow.at(k));
                        sample.serviceRow.at(k)=1;
                        exportTotal+=nodeExport(k);
                        sample.serviceSerial.push_back(k);
                }
                ////cout<<"creatOneChro"<<endl;
        } while(exportTotal<Cons_band);
/*	int data=0;
   for(auto it:sample.serviceRow)
   {
   if(it==1)
   data++;
   }
   //cout<<"data "<<data<<endl;*/
        return sample;
}

void initialize_population(const Graph &g,const Consume &c,const int &pop_size,vector<chromosome> &population)
{
        population.clear();
        for(int i=0; i<pop_size; i++)
                population.push_back(creatOneChro(g,c));
        /*     for(auto it:population)
             {
                    // ////cout<<"population initial:"<<it.serviceNum<<" serviceSerial: ";
                     for(int i=0; i<it.serviceNum; i++)
                             //cout<<it.serviceSerial.at(i)<<"  "<<endl;
             }*/
}

void variation(chromosome &sample,Consume &cons,const int &factor,Graph & gra)
{
        int secondNum;
        int firstNum;

/*        if(sample.serviceNum>cons.node_num)
        {
            do
            {
                firstNum = random(sample.serviceRow.size()-1);
            }
            while(firstNum<2||sample.serviceRow.at(firstNum)==1);
            //cout<<firstNum<<endl;
            sample.serviceRow.at(firstNum) = 1;
              do  secondNum = random(sample.serviceSerial.size());
              while(secondNum<0||secondNum>(sample.serviceSerial.size()-1));
                sample.serviceRow.at(sample.serviceSerial.at(secondNum)) = 0;
                sample.serviceSerial.erase(sample.serviceSerial.begin()+secondNum);
                sample.serviceSerial.push_back(firstNum);
                return;
        }*/

        // else
        // cout<<"sample.serviceNum before "<<sample.serviceNum<<endl;
        firstNum = gra.node_num/100;//pow(2,factor-1);TODO
        int one_count = 0;
        //cout<<"sample.serviceNum + firstNum + 2- sample.serviceRow.size():"<<sample.serviceNum + firstNum + 2- (int)sample.serviceRow.size()<<endl;
        if(abs(sample.serviceNum + firstNum + 2- (int)sample.serviceRow.size())<0.1*sample.serviceRow.size())
        {
                sample = best_solution;
                    //    cout<<"sample.serviceNum come int "<<sample.serviceNum<<endl;
                return;
        }
        for(int i=0; i<firstNum; i++)
        {

                do
                {

                        secondNum = random(sample.serviceRow.size());
                }
                while(secondNum<2||sample.serviceRow.at(secondNum)==1);
                sample.serviceRow.at(secondNum) = 1;
                //    //cout<<secondNum<<" ";
                sample.serviceSerial.push_back(secondNum);
                sample.serviceNum++;
        }
        // //cout<<"sample.serviceNum "<<sample.serviceNum<<endl;
        /*  do
              firstNum = random(sample.serviceRow.size());
           while(firstNum<2||sample.serviceRow.at(firstNum)==1);
           sample.serviceRow.at(firstNum) = 1;
           sample.serviceSerial.push_back(firstNum);
           sample.serviceNum++;
           }*/
}
chromosome nextGeneration(vector<chromosome> &population,Consume &cons,Graph &g,const int &s_price,vector<pair<int,pair<int,int > > >&vir)
{
        vector<double> probability;
        vector<chromosome> newPopulation(0);
        double accumulatePro=0;
        double totleCost=0.0;
        probability.clear();
        newPopulation.clear();
        chromosome curentBest;
        curentBest.cost = INF;
        int factor=0;
        for(vector<chromosome>::iterator it = population.begin(); it!=population.end(); it++)
        {
                cost = 0;
                pi1 = 0;
                reset(g,vir,cons);
                // //cout<<"real data: "<<endl;
/*		for(int i=0;i<(it->serviceRow).size();i++)
   {
   if((it->serviceRow)[i]==1){}
   //	//cout<<i<<"  ";
   }*/
                //cout<<"LOOP:**********************************************8 "<<endl;
            //    for(auto loca:it->serviceSerial)
                        //cout<<loca<<"  "<<endl;
             //   cout<<"serviceNum: "<<it->serviceNum<<endl;
                calcuZKW(it->serviceRow,it->serviceNum,g,cons,s_price);
//check(cons);
//return curentBest;
             //   cout<<"calcuZKW success"<<endl;
                it->cost = cost;
             //   cout<<"cost:"<<cost<<endl;
                it->chromWayList = wayList;
                if(check(cons,it->serviceSerial,*it))
                {
                        factor = 0;
                        it->flag = true;
                        //   //cout<<"check success"<<endl;
                }
                else
                {
                        factor++;
                        it->cost = INF;
                                // cout<<"cheak fail"<<endl;
                        variation(*it,cons,factor,g);
                        //    //cout<<"debug2"<<endl;
                        it--;
                        continue;
                        //	return curentBest;
                }
                totleCost+=1.0/it->cost;

           //     cout<<"totleCost: "<<totleCost<<endl;
                if(it->cost < curentBest.cost)
                {
                        curentBest = *it;

                }
                if(it->cost<best_solution.cost)
                        best_solution = *it;

        }

        // //cout<<"curentBest caculate"<<endl;
//	return curentBest;
//	//cout<<"probalility: "<<endl;

        for(vector<chromosome>::iterator it = population.begin(); it!=population.end(); it++)
        {
     //         cout<<"it->cost: "<<it->cost<<" "<<"totleCost :"<<totleCost<<endl;
                it->fitness = 1.0/(it->cost*1.0)/(totleCost*1.0);
                accumulatePro+=it->fitness;
//	//cout<<accumulatePro<<" ";
                probability.push_back(accumulatePro);
        }
        newPopulation.push_back(best_solution);
        newPopulation.push_back(curentBest);
        for(int i=0; i<population.size()-2; i++)
        {
                double randomly = rand()%10000*0.0001;
                //    //cout<<"randomly"<<randomly;
                for(int j=0; j<population.size(); j++)
                {
                        if(randomly<probability.at(j))
                        {
//		//cout<<"j"<<j<<" ";
                                newPopulation.push_back(population.at(j));
//		//cout<<"seond generation serviceNUm: "<<population.at(j).serviceNum<<" ";
//		//cout<<"seond generation serviceNUm: "<<population.at(j).cost<<endl;
                                break;
                        }
                }
        }
        ////cout<<"return"<<endl;
        //return curentBest;
        int randomFirst,randSecond,tempData;
        std::random_shuffle(newPopulation.begin(),newPopulation.end());
        for(vector<chromosome>::iterator it=newPopulation.begin(); it!=newPopulation.end()-2; it=it+2)//交叉
        {
                do randomFirst = random(g.node_num+2);
                while(randomFirst<2);
                do randSecond = random(g.node_num+2);
                while(randomFirst==randSecond||randSecond<2);
                if(randSecond<randomFirst)
                        swap(randomFirst,randSecond);
                for(int i=randomFirst; i<randSecond; i++)
                {
                        if(it->serviceRow.at(i)==(it+1)->serviceRow.at(i)) {}
                        else
                        {
                                tempData = it->serviceRow.at(i);
                                it->serviceRow.at(i) = (it+1)->serviceRow.at(i);
                                (it+1)->serviceRow.at(i) = tempData;
                        }
                }
        }
        double changePro = 1.0/g.node_num*1.0;
        int d=0;
        for(vector<chromosome>::iterator it=newPopulation.begin(); it!=newPopulation.end(); it++)
        {
                d=1;
                it->serviceNum = 0;
                it->serviceSerial.clear();
                for(vector<int>::iterator j=(it->serviceRow).begin()+2; j!=(it->serviceRow).end(); j++)
                {
                        d++;
                        if(rand()%10000*0.0001<changePro)
                        {
                                if(*j==1)
                                        *j=0;
                                else
                                        *j=1;
                        }
                        if(*j==1)
                        {
                                (it->serviceNum)++;
                                it->serviceSerial.push_back(d);
                        }
                }

        }
        population = newPopulation;
        return curentBest;
}

//You need to complete the function
void deploy_server(char * topo[MAX_EDGE_NUM], int line_num,char * filename)
{
        clock_t start, finish;
        double duration;


        //////////cout<<"-------------pre process-----------"<<endl;
        int s_price = 0;
        Graph graph;
        Consume cons;//消费节点
        int newCost;

        /*-------------------遗传----------------------------*/
        int pop_size = 10;//TODO
        int cunt = 0;
        int maxe_generation = T;
        int generation=0;
        cal_mat(topo, graph, cons, line_num, s_price);//计算邻接矩阵等数据
        //    print_graph(graph,cons);

        ////cout<<"-------------add_edges--------------"<<endl;
        super_source = 1;
        super_sink = graph.node_num + graph.edge_num + cons.node_num +  2;
        add_sink_edges(graph, cons);
        vector<pair<int,pair<int,int> > > virtual_node;
        add_net_edges(graph, virtual_node);
        add_source_edges(graph);
        //save copy of e
        memcpy(e_buf,e,Max_Edge * sizeof(size_t));
        Pe-=Peppcount;
        memcpy(Pe_buf,Pe,Max_Edge * sizeof(Pe));

        reset(graph,virtual_node,cons);
        // print_edges();
        // auto console = spdlog::stdout_color_mt("console");
        // console->info("Welcome to spdlog!");
        // auto my_logger = spdlog::basic_logger_mt("basic_logger", "logs/basic.txt");
        // my_logger->info("Some log message");
        // exit(0);
//*********************************Loop Start****************************************//
        //////////cout<<"------select service location------"<<endl;
        srand(time(NULL));
        int numnum=0;
        // cout<<"before initialize_population success"<<endl;
        initialize_population(graph,cons,pop_size,PopulationVec);
        // cout<<"initialize_population success"<<endl;
        best_solution.cost = INF;

        while(generation<maxe_generation)
        {
                cost = 0;
                pi1 = 0;

                reset(graph,virtual_node,cons);
                // cout<<"reset success"<<endl;
                resultChrom = nextGeneration(PopulationVec,cons,graph,s_price,virtual_node);

                if(resultChrom.cost>best_solution.cost)
                        cunt++;
                else
                        cunt=0;
                // printPathway(resultChrom.chromWayList);
                // cout<<"resultChrom info: "<<endl;
                // cout<<"result cost: "<<resultChrom.cost<<endl;
                // cout<<"result seviceNum: "<<resultChrom.serviceNum<<endl;
                // cout<<"result seviceLoc: ";

                // for(auto it:resultChrom.serviceSerial)
                // cout<<it<<" ";
                // cout<<endl;
                generation++;
                // //cout<<"     generation"<<     generation<<"  ";
                if(cunt>30) //TODO
                        break;

                finish = clock();
                duration = (double)(finish - start) / CLOCKS_PER_SEC;
                if(duration>87) break;
        }

        // printPathway(best_solution.chromWayList);
        // cout<<"best_solution info: "<<endl;
        // cout<<"best cost: "<<best_solution.cost<<endl;
        // cout<<"best seviceNum: "<<best_solution.serviceNum<<endl;
        // cout<<"best seviceLoc: ";
        // for(auto it:best_solution.serviceSerial)
        //         cout<<it<<" ";
        // cout<<endl;


// print_edges();
// select_edge(selected_edge, virtual_node, graph.node_num);
//*********************************Loop End****************************************//

// Output demo

        string output = to_string(wayList.size()-1);
        output += "\n\n";
        // if(p<graph.node_num+2 && p>1)
        // {
        //         cWay.push_back(p-2);
        // }
        // else if(p>graph.node_num+graph.edge_num+1)
        // {
        //         if(p<graph.node_num+graph.edge_num+cons.node_num+2)
        //         {
        //                 cWay.push_back(p-graph.node_num-graph.edge_num-2);
        //         }
        // }
        for(int i = 1; i < wayList.size(); i++)
        {
                for(int j = wayList.at(i).size()-1; j>=0; j--)
                {
                        if(wayList.at(i).at(j)<=graph.node_num+1 && wayList.at(i).at(j)>1)
                        {
                                output += to_string(wayList.at(i).at(j));
                                output += " ";
                        }
                       if(wayList.at(i).at(j)>graph.node_num+graph.edge_num+1 && wayList.at(i).at(j)<super_sink)
                        {
                                output += to_string(wayList.at(i).at(j)-graph.node_num-graph.edge_num-2);
                                output += " ";
                        }

                }
                output+=to_string(wayBand.at(i-1));
                ////cout<<"wayBand:"<<wayBand.at(i-1)<<endl;
                if(i!=wayList.size()-1)
                        output += "\n";
        }
        ////cout<<output<<endl;
        char * topo_file = (char *)malloc((output.length()-1)*sizeof(char));
        topo_file = &output.at(0);
        // output.copy(topo_file,output.length(),0);

        write_result(topo_file, filename);
        //////////cout<<"-----------END--------------------"<<endl;
}
