import networkx as nx
import matplotlib.pyplot as plt
import community
def show_net(case_num,edge_show):
    # case_num = raw_input("Assign case to plot,range:(0~4)? ")
    # edge_show = raw_input("Show edge weight:y/n? ")
    file = open('/home/w/huwei_2017/case_example/case' + str(case_num) + '.txt','r')
    G = nx.Graph()
    line = file.readline()
    line = file.readline()
    line = file.readline()
    line = file.readline()
    consume_node = []
    node_labels = {}
    while 1:
        line = file.readline()
        list = line.strip()
        list = line.split(' ')
        if len(list)<3:
            break;
        G.add_edge(list[0],list[1],weight=int(list[2]))
    while 1:
        line = file.readline()
        list = line.strip()
        list = line.split(' ')
        if len(list)<3:
            break;
            # consume_node.append(list[1])
        consume_node.append(str("x"+list[0]))
        G.add_edge(list[1],str("x"+list[0]),weight=int(list[2].strip()))

    for v in G.nodes():
        node_labels[v] = v

        pos=nx.spring_layout(G)
        partition = community.best_partition(G)

#drawing
    size = float(len(set(partition.values())))
    pos = nx.spring_layout(G)
    count = 0.
    for com in set(partition.values()) :
        count = count + 1.
        list_nodes = [nodes for nodes in partition.keys()
                                    if partition[nodes] == com]
        nx.draw_networkx_nodes(G, pos, list_nodes, node_size = 150)

    nx.draw(G, pos,node_color='g')
    nx.draw(G, pos,nodelist=consume_node,color='r')
    nx.draw_networkx_labels(G,pos,labels=node_labels)
    if str(edge_show)=='y':
        edge_labels=dict([((u,v,),d['weight'])
                    for u,v,d in G.edges(data=True)])
    nx.draw_networkx_edge_labels(G,pos,edge_labels=edge_labels)

    plt.axis('off')
    plt.show()

# if __name__=='__main__':
    # show_net()
