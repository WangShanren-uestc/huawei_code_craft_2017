#ifndef __DEPLOY_H
#define __DEPLOY_H

#include "lib_io.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
#include <iostream>
#include <typeinfo>
#include <ctype.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <time.h>
#include <algorithm>


#define random(x) (rand()%x)
void deploy_server(char * graph[MAX_EDGE_NUM], int edge_num, char * filename);

struct Graph {
        int node_num, edge_num;// 顶点数 边数
        std::vector<int> nodes;
        std::vector<std::pair<int,int>> edges;
        std::vector<std::pair<int,int>> supply;
        // std::vector<std::vector<std::pair<int,int>> > mat;  // 邻接矩阵,pair（带宽，单价）
};

struct Consume {
        int node_num; // 顶点数
        std::vector<int> nodes;   //
        std::vector<int> demand;
};


struct etype
{
        int t,c,u;
        etype *next,*pair;
        etype(){
        }
        etype(int t_,int c_,int u_,etype* next_) :
                t(t_),c(c_),u(u_),next(next_){
        }
        void* operator new(long unsigned int,void* p){
                return p;
        }
};

#endif
